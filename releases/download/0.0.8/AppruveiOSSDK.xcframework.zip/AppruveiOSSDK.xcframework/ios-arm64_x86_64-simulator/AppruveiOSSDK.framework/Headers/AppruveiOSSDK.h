//
//  AppruveiOSSDK.h
//  AppruveiOSSDK
//
//  Created by Laud Bruce on 09/11/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for AppruveiOSSDK.
FOUNDATION_EXPORT double AppruveiOSSDKVersionNumber;

//! Project version string for AppruveiOSSDK.
FOUNDATION_EXPORT const unsigned char AppruveiOSSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AppruveiOSSDK/PublicHeader.h>


